package hk.edu.polyu.comp.comp2021.test;


import org.junit.Test;

/**
 *
 */
public class MonopolyTest {
    /**
     * Test Case
     * @throws Exception E
     */
    @Test
    public void main() throws Exception {

    }

    /**
     * Setup
     * @throws Exception e
     */
    @org.junit.Before
    public void setUp() throws Exception {

    }

}