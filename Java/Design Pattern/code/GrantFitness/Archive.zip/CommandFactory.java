package GrantFitness;

public interface CommandFactory {

    public abstract Command createCommand();

}
