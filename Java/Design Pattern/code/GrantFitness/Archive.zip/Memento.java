package GrantFitness;

public interface Memento {

    public abstract void restore();

}
